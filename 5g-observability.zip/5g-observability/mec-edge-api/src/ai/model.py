from __future__ import annotations
from typing import List, Dict, Optional, Tuple, Union
import os, json, pickle
import numpy as np
from dataclasses import dataclass

import torch, torch.nn as nn, torch.nn.functional as F
from torch.utils.data import TensorDataset, DataLoader

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# -------- storage locations --------
DATA_DIR   = os.environ.get("MODEL_DATA_DIR", "/app/data")
os.makedirs(DATA_DIR, exist_ok=True)
MODEL_PT   = os.path.join(DATA_DIR, "global_model.pt")     # torch state_dict
SCALER_PKL = os.path.join(DATA_DIR, "scaler.pkl")          # sklearn scaler
META_JSON  = os.path.join(DATA_DIR, "model_meta.json")     # feature order + class names

# Defaults for your dataset
DEFAULT_CSVS = [
    "./data/UL-ECE-5G-AV-DDoS2025.csv",
    "./data/5G_V2N_Communication_Dataset.csv",
]
DEFAULT_LABEL = os.getenv("MODEL_LABEL_COL", "Attack_Type")
DEFAULT_FEATURES = [
    "Latitude","Longitude","Speed","Acceleration","Throttle","Steering","Brake",
    "Network_Latency","Packet_Loss","Throughput","Jitter","Bandwidth_Utilization",
    "sim_packet_rate",
    "sim_conn_attempts",
    "sim_error_rate" 
]
DEFAULT_SEP = os.getenv("MODEL_SEP", "").strip() or None

# -------- config --------
@dataclass
class TrainCfg:
    hidden: int = 64
    epochs: int = 4
    batch_size: int = 128
    lr: float = 1e-3
    weight_decay: float = 1e-5
    test_size: float = 0.1
    random_state: int = 42

CFG = TrainCfg()

# -------- model --------
class MLP(nn.Module):
    def __init__(self, in_dim: int, hidden: int, out_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(in_dim, hidden)
        self.fc2 = nn.Linear(hidden, hidden)
        self.out = nn.Linear(hidden, out_dim)
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.out(x)  # logits

# singletons
_model: Optional[nn.Module] = None
_in_dim: Optional[int] = None

# -------- meta/scaler helpers --------
def _save_scaler(s: StandardScaler):
    with open(SCALER_PKL, "wb") as f: pickle.dump(s, f)

def _load_scaler() -> Optional[StandardScaler]:
    if os.path.exists(SCALER_PKL):
        with open(SCALER_PKL, "rb") as f: return pickle.load(f)
    return None

def _save_meta(meta: Dict):
    with open(META_JSON, "w") as f: json.dump(meta, f, indent=2)

def _load_meta() -> Dict:
    if not os.path.exists(META_JSON):
        raise RuntimeError("Model meta not found. Train at least once or aggregate weights.")
    with open(META_JSON, "r") as f: return json.load(f)

def _init_model(in_dim: int, out_dim: int) -> nn.Module:
    global _model, _in_dim
    if _model is None or _in_dim != in_dim:
        _model = MLP(in_dim=in_dim, hidden=CFG.hidden, out_dim=out_dim)
        _in_dim = in_dim
        if os.path.exists(MODEL_PT):
            _model.load_state_dict(torch.load(MODEL_PT, map_location="cpu"))
        _model.eval()
    return _model

# -------- vectorize state for FedAvg --------
def state_dict_to_vector(sd: Dict[str, torch.Tensor]) -> np.ndarray:
    parts = [p.detach().cpu().numpy().ravel() for _, p in sd.items()]
    return np.concatenate(parts)

def vector_to_state_dict(vec: np.ndarray, ref_sd: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
    out, idx = {}, 0
    for k, t in ref_sd.items():
        n = t.numel()
        out[k] = torch.tensor(vec[idx:idx+n].reshape(t.shape), dtype=t.dtype)
        idx += n
    if idx != vec.size: raise ValueError("Vector length mismatch")
    return out

def _apply_global_vector(vec: np.ndarray, in_dim: int, out_dim: int):
    m = _init_model(in_dim, out_dim)
    ref = m.state_dict()
    m.load_state_dict(vector_to_state_dict(vec, ref))
    m.eval()
    torch.save(m.state_dict(), MODEL_PT)

# -------- CSV utils --------
def _read_csv(path: str, sep: Optional[str] = DEFAULT_SEP) -> pd.DataFrame:
    return pd.read_csv(path, sep=None if sep is None else sep, engine="python" if sep is None else "c")

def _find_csv() -> str:
    for p in DEFAULT_CSVS:
        if os.path.exists(p): return p
    raise RuntimeError("No CSV found in ./data/. Provide one or set DEFAULT_CSVS.")

# -------- public: training (client/local) --------
def train_local_on_csv(csv_path: Optional[str] = None,
                       label_col: str = DEFAULT_LABEL,
                       feature_cols: Optional[List[str]] = None,
                       epochs: Optional[int] = None,
                       sep: Optional[str] = None
                       ) -> Tuple[List[float], int, Dict]:
    """
    Trains locally on a CSV slice and returns (weights_vector, samples_used, meta)
    meta includes: feature_order, class_names, in_dim, out_dim
    """
    csv = csv_path or _find_csv()
    df = _read_csv(csv, sep=sep)
    feats = feature_cols or DEFAULT_FEATURES
    X = df[feats].astype(np.float32).values
    y_raw = df[label_col].astype(str).values  # map to string labels

    # build class map (stable order)
    class_names = sorted(pd.Series(y_raw).unique().tolist())
    class_to_idx = {c:i for i,c in enumerate(class_names)}
    y = np.array([class_to_idx[v] for v in y_raw], dtype=np.int64)

    # scale
    scaler = _load_scaler() or StandardScaler()
    X = scaler.fit_transform(X)
    _save_scaler(scaler)

    # split for actual training set size (samples count)
    X_tr, _, y_tr, _ = train_test_split(
        X, y, test_size=CFG.test_size, random_state=CFG.random_state, stratify=y
    )
    in_dim, out_dim = X.shape[1], len(class_names)
    m = _init_model(in_dim, out_dim)
    m.train()

    opt = torch.optim.Adam(m.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)
    loss_fn = nn.CrossEntropyLoss()

    ds = TensorDataset(torch.from_numpy(X_tr), torch.from_numpy(y_tr))
    dl = DataLoader(ds, batch_size=CFG.batch_size, shuffle=True)

    ep = epochs or CFG.epochs
    for _ in range(ep):
        for xb, yb in dl:
            opt.zero_grad()
            logits = m(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            opt.step()

    # produce update vector
    vec = state_dict_to_vector(m.state_dict()).astype(np.float32)
    meta = {
        "feature_order": feats,
        "class_names": class_names,
        "in_dim": in_dim,
        "out_dim": out_dim
    }
    return vec.tolist(), int(X_tr.shape[0]), meta

# -------- public: FedAvg on server --------
def fedavg_vectors(updates: List[Dict]) -> List[float]:
    """
    updates: [{"weights":[...], "samples": int}, ...]
    """
    if not updates: raise ValueError("No client updates")
    L = len(updates[0]["weights"])
    total = sum(int(u["samples"]) for u in updates)
    if total <= 0: raise ValueError("Total samples must be > 0")
    agg = np.zeros(L, dtype=np.float32)
    for u in updates:
        w = np.array(u["weights"], dtype=np.float32)
        if w.size != L: raise ValueError("Inconsistent weight lengths across clients")
        agg += w * (int(u["samples"]) / total)
    return agg.tolist()

def set_global_weights(weights: List[float], feature_order: List[str], class_names: List[str], in_dim: int, out_dim: int):
    # persist meta + weights
    _save_meta({"feature_order": feature_order, "class_names": class_names, "in_dim": in_dim, "out_dim": out_dim})
    vec = np.array(weights, dtype=np.float32)
    _apply_global_vector(vec, in_dim, out_dim)

# -------- public: inference --------
def get_model_info() -> Dict[str, object]:
    meta = _load_meta()  # raises if not present
    return meta

def predict_full(payload: Union[List[float], Dict[str, float]]) -> Dict[str, object]:
    meta = _load_meta()
    feats = meta["feature_order"]
    class_names = meta["class_names"]
    in_dim, out_dim = meta["in_dim"], meta["out_dim"]

    # load scaler + model
    scaler = _load_scaler()
    if scaler is None: raise RuntimeError("Scaler not found. Train/aggregate first.")
    m = _init_model(in_dim, out_dim)

    # build X row
    if isinstance(payload, list):
        X = np.asarray(payload, dtype=np.float32).reshape(1, -1)
        if X.shape[1] != len(feats): raise ValueError(f"Expected {len(feats)} features, got {X.shape[1]}")
    elif isinstance(payload, dict):
        row = [payload.get(k, 0.0) for k in feats]
        X = np.asarray(row, dtype=np.float32).reshape(1, -1)
    else:
        raise TypeError("payload must be list[float] or dict[str,float]")

    X = scaler.transform(X)
    with torch.no_grad():
        logits = m(torch.from_numpy(X))
        probs = torch.softmax(logits, dim=1).cpu().numpy()[0]
    idx = int(np.argmax(probs))
    return {
        "predicted_class": str(class_names[idx]),
        "probs": {str(class_names[i]): float(probs[i]) for i in range(len(class_names))}
    }

# -------- convenience: initialize meta from a CSV (server-side bootstrap) --------
def bootstrap_from_csv(csv_path: Optional[str] = None,
                       label_col: str = DEFAULT_LABEL,
                       feature_cols: Optional[List[str]] = None,
                       sep: Optional[str] = None) -> Dict[str, object]:
    """
    For first-time setup on server (not FL training): read CSV to derive scaler + meta and save an initial model.
    """
    csv = csv_path or _find_csv()
    df = _read_csv(csv, sep=sep)
    feats = feature_cols or DEFAULT_FEATURES
    X = df[feats].astype(np.float32).values
    y_raw = df[label_col].astype(str).values
    class_names = sorted(pd.Series(y_raw).unique().tolist())
    in_dim, out_dim = X.shape[1], len(class_names)

    # fit scaler only
    scaler = StandardScaler().fit(X)
    _save_scaler(scaler)

    # init zero weights model & save meta
    m = _init_model(in_dim, out_dim)
    torch.save(m.state_dict(), MODEL_PT)
    _save_meta({"feature_order": feats, "class_names": class_names, "in_dim": in_dim, "out_dim": out_dim})
    return get_model_info()

