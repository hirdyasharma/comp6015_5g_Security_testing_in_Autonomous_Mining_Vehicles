from fastapi import FastAPI, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List, Union
import time

from prometheus_client import Counter, Gauge, generate_latest, CONTENT_TYPE_LATEST
from src.ai.model import (
    train_local_on_csv, fedavg_vectors, set_global_weights,
    get_model_info, predict_full, bootstrap_from_csv
)

app = FastAPI(title="MEC Edge API", version="0.3.0 (FL + probs)")

# ===== In-memory stores =====
RNIS_LATEST: Dict[str, Dict[str, Any]] = {}
LOCATIONS: Dict[str, Dict[str, Any]] = {}
TRAFFIC_RULES: List[Dict[str, Any]] = []

# ===== Metrics =====
rnis_samples = Counter("mec_rnis_samples_total", "RNIS samples ingested", ["ue_id","cell_id"])
rnis_rsrp = Gauge("mec_rnis_rsrp", "Latest RSRP", ["ue_id","cell_id"])

ai_predictions = Counter("mec_ai_predictions_total", "AI predictions served")
# NEW: AI verdict metrics (for Grafana)
ai_attack_level = Gauge(
    "mec_ai_attack_level",
    "AI predicted class probability (winner)",
    ["vehicle","predicted_class"]
)
ai_prob = Gauge(
    "mec_ai_prob",
    "AI per-class probability",
    ["vehicle","class_name"]
)

fl_rounds = Counter("mec_fl_rounds_total", "FedAvg rounds completed")

# ===== Schemas =====
class RNISSample(BaseModel):
    ue_id: str
    cell_id: str
    rsrp: float = Field(..., ge=-140, le=-20)
    rsrq: float = Field(..., ge=-30, le=0)
    cqi: int = Field(..., ge=0, le=15)
    sinr: float = Field(..., ge=-10, le=30)
    cell_load: float = Field(..., ge=0.0, le=1.0)
    ts_ms: Optional[int] = None

class LocationUpdate(BaseModel):
    ue_id: str
    lat: float
    lon: float
    speed_mps: Optional[float] = 0.0
    heading_deg: Optional[float] = 0.0
    ts_ms: Optional[int] = None

class TrafficRule(BaseModel):
    rule_id: str
    ue_id: Optional[str] = None
    path: str
    priority: int = 100
    action: str = "local_breakout"

# AI
class PredictInput(BaseModel):
    # You can send either a raw ordered feature vector, or a map keyed by feature names
    features: Optional[List[float]] = None
    features_map: Optional[Dict[str, float]] = None
    # Optional vehicle/ue id to label metrics
    vehicle: Optional[str] = "veh-A"

class FLClientUpdate(BaseModel):
    client_id: str
    weights: List[float]
    samples: int
    # meta only needed on first aggregation to establish model shape/class names
    feature_order: Optional[List[str]] = None
    class_names: Optional[List[str]] = None
    in_dim: Optional[int] = None
    out_dim: Optional[int] = None

class TrainLocalReq(BaseModel):
    csv_path: Optional[str] = None
    label_col: Optional[str] = "Attack_Type"
    features: Optional[List[str]] = None
    epochs: Optional[int] = None
    sep: Optional[str] = None

class BootstrapReq(BaseModel):
    csv_path: Optional[str] = None
    label_col: Optional[str] = "Attack_Type"
    features: Optional[List[str]] = None
    sep: Optional[str] = None

# ===== Routes =====
@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/rnis/reports")
def push_rnis(sample: RNISSample):
    data = sample.dict()
    data["ts_ms"] = data.get("ts_ms") or int(time.time()*1000)
    RNIS_LATEST.setdefault(sample.ue_id, {})[sample.cell_id] = data
    rnis_samples.labels(sample.ue_id, sample.cell_id).inc()
    rnis_rsrp.labels(sample.ue_id, sample.cell_id).set(sample.rsrp)
    return {"ok": True}

@app.get("/rnis/reports/latest")
def get_rnis_latest():
    return RNIS_LATEST

@app.post("/location/devices")
def update_location(loc: LocationUpdate):
    d = loc.dict()
    d["ts_ms"] = d.get("ts_ms") or int(time.time()*1000)
    LOCATIONS[loc.ue_id] = d
    return {"ok": True}

@app.get("/location/devices/{ue_id}")
def get_location(ue_id: str):
    if ue_id not in LOCATIONS:
        raise HTTPException(404, "Unknown UE")
    return LOCATIONS[ue_id]

@app.post("/traffic/rules")
def post_rule(rule: TrafficRule):
    TRAFFIC_RULES.append(rule.dict())
    return {"ok": True, "count": len(TRAFFIC_RULES)}

# ------ FL endpoints ------
@app.post("/ai/fl/train_local")
def ai_fl_train_local(req: TrainLocalReq):
    try:
        vec, samples, meta = train_local_on_csv(
            csv_path=req.csv_path,
            label_col=req.label_col or "Attack_Type",
            feature_cols=req.features,
            epochs=req.epochs,
            sep=req.sep,
        )
        return {"weights": vec, "samples": samples, "meta": meta}
    except Exception as e:
        raise HTTPException(400, f"Local FL train failed: {e}")

@app.post("/ai/fl/aggregate")
def ai_fl_aggregate(updates: List[FLClientUpdate]):
    if not updates:
        raise HTTPException(400, "No updates provided")

    first = updates[0]
    try:
        agg = fedavg_vectors([{"weights": u.weights, "samples": u.samples} for u in updates])
        if first.feature_order and first.class_names and first.in_dim and first.out_dim:
            set_global_weights(agg, first.feature_order, first.class_names, first.in_dim, first.out_dim)
        else:
            meta = get_model_info()
            set_global_weights(agg, meta["feature_order"], meta["class_names"], meta["in_dim"], meta["out_dim"])
    except Exception as e:
        raise HTTPException(400, f"Aggregation failed: {e}")

    fl_rounds.inc()
    return {"ok": True}

@app.post("/ai/bootstrap")
def ai_bootstrap(req: BootstrapReq):
    """One-time helper to create scaler & meta from a CSV before receiving any FL updates."""
    try:
        info = bootstrap_from_csv(req.csv_path, req.label_col or "Attack_Type", req.features, req.sep)
        return {"ok": True, "info": info}
    except Exception as e:
        raise HTTPException(400, f"Bootstrap failed: {e}")

@app.get("/ai/info")
def ai_info():
    try:
        return get_model_info()
    except Exception as e:
        raise HTTPException(400, f"AI info failed: {e}")

@app.post("/ai/predict")
def ai_predict(inp: PredictInput):
    if inp.features is None and inp.features_map is None:
        raise HTTPException(400, "Provide either 'features' (list) or 'features_map' (object)")
    payload: Union[List[float], Dict[str, float]] = inp.features if inp.features is not None else inp.features_map
    try:
        out = predict_full(payload)
    except Exception as e:
        raise HTTPException(400, f"AI predict failed: {e}")
    ai_predictions.inc()

    # record verdict metrics
    vehicle = inp.vehicle or "veh-A"
    pred_class = out.get("predicted_class", "Unknown")
    probs = out.get("probs", {})

    # NOTE: prometheus_client expects positional label values in declared order
    # Winner level
    ai_attack_level.labels(vehicle, pred_class).set(float(probs.get(pred_class, 0.0)))
    # All per-class probs
    for cls, p in probs.items():
        ai_prob.labels(vehicle, str(cls)).set(float(p))

    return out

@app.get("/metrics")
def metrics():
    return PlainTextResponse(generate_latest(), media_type=CONTENT_TYPE_LATEST)

