#!/usr/bin/env python3
import sys, math
import pandas as pd

"""
Usage:
  python3 preprocess_to_model_csv.py input.csv output.csv

Outputs a CSV with:
  Features:
    Latitude, Longitude, Speed, Acceleration, Throttle, Steering, Brake,
    Network_Latency, Packet_Loss, Throughput, Jitter, Bandwidth_Utilization,
    sim_packet_rate, sim_conn_attempts, sim_error_rate
  Label:
    Attack_Type  in {Normal, DDoS, UDP, TCP, ICMP, Other}
"""

REQ = [
  "Latitude","Longitude","Speed","Acceleration","Throttle","Steering","Brake",
  "Network_Latency","Packet_Loss","Throughput","Jitter","Bandwidth_Utilization",
  "sim_packet_rate","sim_conn_attempts","sim_error_rate",
  "Attack_Type"
]

def lower(s): return (str(s).strip().lower() if pd.notna(s) else "")

def main(inp, outp):
    df = pd.read_csv(inp)

    # --- helper getters with fallbacks ---
    def get_col(*cands):
        for c in cands:
            if c in df.columns: return c
        return None

    # Speed (prefer 'Speed' in m/s; else derive from 'Speed (km/h)')
    speed_col = get_col("Speed")
    if not speed_col:
        kmh = get_col("Speed (km/h)")
        if kmh:
            df["Speed"] = pd.to_numeric(df[kmh], errors="coerce")/3.6
        else:
            df["Speed"] = 0.0  # fallback
    # Network_Latency (ms)
    if "Network_Latency" not in df.columns:
        lat_ms = get_col("Latency (ms)")
        df["Network_Latency"] = pd.to_numeric(df[lat_ms], errors="coerce") if lat_ms else 0.0
    # Packet_Loss (expect 0..1; if 0..100% scale down)
    if "Packet_Loss" in df.columns:
        pl = pd.to_numeric(df["Packet_Loss"], errors="coerce")
        # Heuristic: if many values >1, assume percentages -> scale
        if (pl > 1.0).sum() > 0.2*len(pl):
            pl = pl/100.0
        df["Packet_Loss"] = pl.clip(lower=0, upper=1)
    else:
        df["Packet_Loss"] = 0.0

    # Throughput (Mbps) — use 'Throughput' if present else 'Throughput (Mbps)'
    if "Throughput" not in df.columns:
        thr = get_col("Throughput (Mbps)")
        df["Throughput"] = pd.to_numeric(df[thr], errors="coerce") if thr else 0.0

    # Jitter
    if "Jitter" not in df.columns:
        df["Jitter"] = 0.0

    # Bandwidth_Utilization (0..1) — if 0..100, scale down
    if "Bandwidth_Utilization" in df.columns:
        bu = pd.to_numeric(df["Bandwidth_Utilization"], errors="coerce")
        if (bu > 1.0).sum() > 0.2*len(bu):
            bu = bu/100.0
        df["Bandwidth_Utilization"] = bu.clip(lower=0, upper=1)
    else:
        # If missing, try Network Load / Resource Allocation as proxy
        load = get_col("Network Load (Mbps)")
        alloc = get_col("Resource Allocation (Mbps)")
        if load and alloc:
            bu = pd.to_numeric(df[load], errors="coerce")/pd.to_numeric(df[alloc], errors="coerce").replace(0, math.nan)
            df["Bandwidth_Utilization"] = bu.fillna(0).clip(lower=0, upper=1)
        else:
            df["Bandwidth_Utilization"] = 0.0

    # Basic pass-through numeric columns if they exist; else create zeros
    for col in ["Latitude","Longitude","Acceleration","Throttle","Steering","Brake"]:
        if col not in df.columns: df[col] = 0.0
        else: df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

    df["Speed"] = pd.to_numeric(df["Speed"], errors="coerce").fillna(0.0)
    df["Network_Latency"] = pd.to_numeric(df["Network_Latency"], errors="coerce").fillna(0.0)
    df["Throughput"] = pd.to_numeric(df["Throughput"], errors="coerce").fillna(0.0)
    df["Jitter"] = pd.to_numeric(df["Jitter"], errors="coerce").fillna(0.0)

    # --- add synthetic helpers (optional but helpful for multi-class) ---
    # sim_packet_rate ≈ (Mbps * 1e6) / (avg packet size bits), assume 12000 bits (~1500B)
    dtr = get_col("Data Transfer Rate (Mbps)")
    if dtr:
        pps = pd.to_numeric(df[dtr], errors="coerce").fillna(0.0)*1_000_000/12000.0
    else:
        pps = 0.0
    df["sim_packet_rate"] = pps

    # sim_conn_attempts — base 5, raise if intrusion type looks TCP-ish
    itcol = get_col("Intrusion Type")
    idet  = get_col("Intrusion Detected")
    base_conn = pd.Series(5.0, index=df.index)
    if itcol:
        it = df[itcol].astype(str).str.lower()
        base_conn += it.str.contains("tcp|syn").astype(float)*50.0
    if idet:
        d = df[idet].astype(str).str.lower()
        base_conn += d.isin(["yes","true","1"]).astype(float)*10.0
    df["sim_conn_attempts"] = base_conn

    # sim_error_rate — from Anomaly Score if present (0..1); else 0
    ascol = get_col("Anomaly Score")
    if ascol:
        er = pd.to_numeric(df[ascol], errors="coerce").fillna(0.0)
        # if score seems 0..100, scale
        if (er > 1.0).sum() > 0.2*len(er):
            er = er/100.0
        df["sim_error_rate"] = er.clip(lower=0, upper=1)
    else:
        df["sim_error_rate"] = 0.0

    # --- label normalization to {Normal, DDoS, UDP, TCP, ICMP, Other} ---
    LABELS = {"normal":"Normal","ddos":"DDoS","udp":"UDP","tcp":"TCP","icmp":"ICMP","other":"Other"}
    if "Attack_Type" in df.columns:
        lbl = df["Attack_Type"].astype(str).str.strip().str.lower()
    else:
        # derive from Intrusion Detected + Intrusion Type
        it = df[itcol].astype(str).str.lower() if itcol else pd.Series("", index=df.index)
        d  = df[idet].astype(str).str.lower() if idet else pd.Series("", index=df.index)
        derived = []
        for i in range(len(df)):
            if d.iloc[i] in ["no","false","0",""]:
                derived.append("normal")
            else:
                t = it.iloc[i]
                if "ddos" in t: derived.append("ddos")
                elif "udp" in t: derived.append("udp")
                elif "tcp" in t or "syn" in t: derived.append("tcp")
                elif "icmp" in t: derived.append("icmp")
                else: derived.append("other")
        lbl = pd.Series(derived)
    lbl = lbl.map(lambda x: LABELS.get(x, "Other"))
    df["Attack_Type"] = lbl

    # --- final frame with required columns in order ---
    out_cols = [
      "Latitude","Longitude","Speed","Acceleration","Throttle","Steering","Brake",
      "Network_Latency","Packet_Loss","Throughput","Jitter","Bandwidth_Utilization",
      "sim_packet_rate","sim_conn_attempts","sim_error_rate",
      "Attack_Type"
    ]
    for c in out_cols:
        if c not in df.columns: df[c] = 0.0 if c != "Attack_Type" else "Normal"

    df_out = df[out_cols].copy()
    # basic cleaning
    for c in out_cols:
        if c != "Attack_Type":
            df_out[c] = pd.to_numeric(df_out[c], errors="coerce").fillna(0.0)

    df_out.to_csv(outp, index=False)
    print(f"Wrote {outp} with {len(df_out)} rows.")
    # show class distribution
    print(df_out["Attack_Type"].value_counts())

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: preprocess_to_model_csv.py input.csv output.csv")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
