#!/usr/bin/env python3
import time, random, argparse, json, sys
import requests

ATTACKS = ["normal", "ddos", "udp", "tcp", "icmp", "other"]

def clamp(v, lo, hi): return max(lo, min(hi, v))

def gen_rnis(kind, intensity):
    rsrp = random.uniform(-105, -75)
    rsrq = random.uniform(-18, -6)
    cqi  = random.randint(8, 15)
    sinr = random.uniform(5, 25)
    load = random.uniform(0.2, 0.7)
    if kind == "ddos":
        load = clamp(load + 0.25*intensity, 0, 1)
        rsrp = clamp(rsrp - 6*intensity, -140, -20)
        rsrq = clamp(rsrq - 3*intensity, -30, 0)
        sinr = clamp(sinr - 5*intensity, -10, 30)
        cqi  = clamp(cqi - int(2*intensity), 0, 15)
    elif kind == "udp":
        load = clamp(load + 0.18*intensity, 0, 1)
        sinr = clamp(sinr - 3*intensity, -10, 30)
    elif kind == "tcp":
        load = clamp(load + 0.15*intensity, 0, 1)
        rsrp = clamp(rsrp - 2*intensity, -140, -20)
    elif kind == "icmp":
        load = clamp(load + 0.10*intensity, 0, 1)
    return dict(
        rsrp=round(rsrp,2),
        rsrq=round(rsrq,2),
        cqi=int(cqi),
        sinr=round(sinr,2),
        cell_load=round(load,3),
    )

def gen_features(kind, intensity):
    f = {
        "Latitude": 0.0,
        "Longitude": 0.0,
        "Speed": random.uniform(10, 70),
        "Acceleration": random.uniform(-1.0, 1.0),
        "Throttle": random.uniform(0.1, 0.8),
        "Steering": random.uniform(-0.5, 0.5),
        "Brake": random.uniform(0.0, 0.3),
        "Network_Latency": random.uniform(15, 60),
        "Packet_Loss": random.uniform(0.0, 0.02),
        "Throughput": random.uniform(6, 40),
        "Jitter": random.uniform(0.5, 6.0),
        "Bandwidth_Utilization": random.uniform(0.2, 0.7),
        "sim_packet_rate": random.uniform(200, 500),
        "sim_conn_attempts": random.uniform(3, 10),
        "sim_error_rate": random.uniform(0.0, 0.02),
    }
    if kind == "ddos":
        f["Network_Latency"] *= (1 + 4.0*intensity)
        f["Packet_Loss"]  = clamp(f["Packet_Loss"] + 0.05*intensity, 0, 1)
        f["Throughput"]   *= (1 + 2.0*intensity)
        f["Jitter"]       *= (1 + 3.0*intensity)
        f["Bandwidth_Utilization"] = clamp(f["Bandwidth_Utilization"] + 0.25*intensity, 0, 1)
        f["sim_packet_rate"] = random.uniform(2000, 6000)*(0.2 + intensity)
        f["sim_conn_attempts"] = random.uniform(20, 200)*intensity
        f["sim_error_rate"] = clamp(f["sim_error_rate"] + 0.10*intensity, 0, 1)
    elif kind == "udp":
        f["Network_Latency"] *= (1 + 2.5*intensity)
        f["Packet_Loss"] = clamp(f["Packet_Loss"] + 0.08*intensity, 0, 1)
        f["Throughput"] *= (0.8 + 1.5*intensity)
        f["Jitter"] *= (1 + 2.0*intensity)
        f["sim_packet_rate"] = random.uniform(1500, 4000)*(0.2 + intensity)
        f["sim_error_rate"] = clamp(f["sim_error_rate"] + 0.08*intensity, 0, 1)
    elif kind == "tcp":
        f["Network_Latency"] *= (1 + 1.5*intensity)
        f["Packet_Loss"] = clamp(f["Packet_Loss"] + 0.03*intensity, 0, 1)
        f["sim_conn_attempts"] = random.uniform(50, 1000)*intensity
        f["sim_error_rate"] = clamp(f["sim_error_rate"] + 0.05*intensity, 0, 1)
    elif kind == "icmp":
        f["Network_Latency"] *= (1 + 1.2*intensity)
        f["Packet_Loss"] = clamp(f["Packet_Loss"] + 0.02*intensity, 0, 1)
        f["sim_packet_rate"] = random.uniform(800, 2000)*(0.2 + intensity)
    elif kind == "other":
        f["sim_error_rate"] = clamp(f["sim_error_rate"] + 0.03*intensity, 0, 1)
    for k, v in f.items():
        if isinstance(v, float): f[k] = float(round(v, 5))
    return f

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://192.168.56.105:8080")
    ap.add_argument("--ues", default="UE1,UE2")
    ap.add_argument("--cells", default="CELL-1,CELL-2")
    ap.add_argument("--vehicles", default="veh-A,veh-B")
    ap.add_argument("--rate", type=float, default=1.0, help="events/sec per UE")
    ap.add_argument("--pattern", choices=["steady","burst"], default="burst")
    ap.add_argument("--atype", choices=ATTACKS, default="ddos")
    ap.add_argument("--intensity", type=float, default=0.9)
    ap.add_argument("--window", type=int, default=30)
    ap.add_argument("--pause", type=int, default=30)
    ap.add_argument("--loc", action="store_true")
    args = ap.parse_args()

    ues = [u.strip() for u in args.ues.split(",") if u.strip()]
    cells = [c.strip() for c in args.cells.split(",") if c.strip()]
    vehicles = [v.strip() for v in args.vehicles.split(",") if v.strip()]

    s = requests.Session()
    hdr = {"Content-Type":"application/json"}

    print(f"Telemetry → {args.base}  pattern={args.pattern} atype={args.atype} rate={args.rate}/s per UE")
    t0 = time.time()
    active = False
    last_switch = t0
    while True:
        now = time.time()
        if args.pattern == "burst":
            if not active and now - last_switch >= args.pause:
                active = True; last_switch = now
                print(f"--- ATTACK START ({args.atype}) ---")
            elif active and now - last_switch >= args.window:
                active = False; last_switch = now
                print(f"--- ATTACK END ---")
        else:
            active = (args.atype != "normal")

        kind = args.atype if active else "normal"

        for idx, ue in enumerate(ues):
            cell = random.choice(cells)
            vehicle = vehicles[idx % len(vehicles)]

            # RNIS
            rnis = gen_rnis(kind, args.intensity)
            rnis_payload = {"ue_id": ue, "cell_id": cell, **rnis}
            try:
                r1 = s.post(f"{args.base}/rnis/reports", json=rnis_payload, timeout=3)
                ok1 = r1.status_code
            except Exception as e:
                ok1 = str(e)

            # AI predict (THIS CALLS YOUR MODEL)
            feats = gen_features(kind, args.intensity)
            try:
                r2 = s.post(f"{args.base}/ai/predict", json={"features_map": feats, "vehicle": vehicle}, timeout=5)
                ok2 = r2.status_code
                pred = r2.json() if ok2 == 200 else {}
                pclass = pred.get("predicted_class","?")
                probs = pred.get("probs",{})
                mxp = max(probs.values()) if probs else 0.0
            except Exception as e:
                ok2 = str(e); pclass = "?"; mxp = 0.0

            # location (optional)
            if args.loc:
                loc = {
                    "ue_id": ue,
                    "lat": -31.95 + random.uniform(-0.02,0.02),
                    "lon": 115.86 + random.uniform(-0.02,0.02),
                    "speed_mps": random.uniform(2, 25),
                    "heading_deg": random.uniform(0, 360),
                }
                try:
                    s.post(f"{args.base}/location/devices", json=loc, timeout=3)
                except Exception:
                    pass

            print(f'[{time.strftime("%H:%M:%S")}] UE={ue} CELL={cell} atk={kind:<5} rnis={ok1} ai={ok2} class={pclass} p={mxp:.2f}')

        time.sleep(max(0.0, 1.0/args.rate))

if __name__ == "__main__":
    main()
